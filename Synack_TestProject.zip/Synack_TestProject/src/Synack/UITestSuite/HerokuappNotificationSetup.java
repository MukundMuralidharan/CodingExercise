package Synack.UITestSuite;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;

import org.testng.annotations.BeforeSuite;


public class HerokuappNotificationSetup {
  public static WebDriver webdriver;
	@BeforeSuite
	public void setup() {
		createWebdriverInstance();
	}
   @AfterSuite
   public void tearDown() {
	   webdriver.quit();
   }
   
   public static void  createWebdriverInstance() {
	   System.setProperty("webdriver.chrome.driver", "./chromedriver");
		webdriver= new ChromeDriver();
		webdriver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
   }
   
}
