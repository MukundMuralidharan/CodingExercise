package Synack.UITestSuite;


import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class HerokuappDisappearElementTest extends HerokuappNotificationSetup {
  @Test
  public void herokuappDisappearAppearTest() {
	  webdriver.navigate().to("https://the-internet.herokuapp.com/disappearing_elements");
	  
	  WebElement element = webdriver.findElement(By.cssSelector("#content > div > ul > li:nth-child(5) > a"));
	  assertTrue(element.isDisplayed());
	  
	  webdriver.get(webdriver.getCurrentUrl());
	  WebElement appelement = webdriver.findElement(By.cssSelector("#content > div > ul > li:nth-child(5) > a"));
	  assertFalse(appelement.isDisplayed());
  }

}
