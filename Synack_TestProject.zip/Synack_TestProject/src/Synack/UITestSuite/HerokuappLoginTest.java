package Synack.UITestSuite;

import org.testng.annotations.Test;


import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;


public class HerokuappLoginTest extends HerokuappNotificationSetup {
	

	@Test
	public void LoginWithNoUsernameTest() {
		String expAlert="Your username is invalid!";
		webdriver.get(" https://the-internet.herokuapp.com/login");
		WebElement login= webdriver.findElement(By.xpath("//button"));
		login.click();
		String alert= webdriver.findElement(By.xpath("//div[@data-alert]")).getText();
		assertTrue(alert.contains(expAlert));
		
	}
	
	@Test
	public void LoginWithInvalidUsernameTest() {
		String expAlert="Your username is invalid!";
		WebElement user= webdriver.findElement(By.xpath("//input[@id=\"username\"]"));
		user.sendKeys("tomsm");		
		WebElement login= webdriver.findElement(By.xpath("//button"));
		login.click();
		String alert= webdriver.findElement(By.xpath("//div[@data-alert]")).getText();
		assertTrue(alert.contains(expAlert));	
		
	}
	
	@Test
	public void LoginWithNoPasswordTest() {
		String expAlert="Your password is invalid!";
		webdriver.get(" https://the-internet.herokuapp.com/login");
		WebElement user= webdriver.findElement(By.xpath("//input[@id=\"username\"]"));
		user.sendKeys("tomsmith");
		WebElement login= webdriver.findElement(By.xpath("//button"));
		login.click();
		String alert= webdriver.findElement(By.xpath("//div[@data-alert]")).getText();
		assertTrue(alert.contains(expAlert));
	}

	@Test
	public void LoginWithInvalidPasswordTest() {
		String expAlert="Your password is invalid!";
		webdriver.get(" https://the-internet.herokuapp.com/login");
		WebElement user= webdriver.findElement(By.xpath("//input[@id=\"username\"]"));
		user.sendKeys("tomsmith");
		WebElement pass= webdriver.findElement(By.xpath("//input[@id=\"password\"]"));
		pass.sendKeys("tomsmith");
		WebElement login= webdriver.findElement(By.xpath("//button"));
		login.click();
		String alert= webdriver.findElement(By.xpath("//div[@data-alert]")).getText();
		assertTrue(alert.contains(expAlert));
	}
	@Test
	public void LoginWithValidDataTest() {
		String expAlert="You logged into a secure area!";
		webdriver.get(" https://the-internet.herokuapp.com/login");
		WebElement user= webdriver.findElement(By.xpath("//input[@id=\"username\"]"));
		user.sendKeys("tomsmith");
		WebElement pass= webdriver.findElement(By.xpath("//input[@id=\"password\"]"));
		pass.sendKeys("SuperSecretPassword!");
		WebElement login= webdriver.findElement(By.xpath("//button"));
		login.click();
		String alert= webdriver.findElement(By.xpath("//div[@data-alert]")).getText();
		assertTrue(alert.contains(expAlert));
	}
	@Test
	public void LogoutTest() {
		
		webdriver.get(" https://the-internet.herokuapp.com/login");
		WebElement user= webdriver.findElement(By.xpath("//input[@id=\"username\"]"));
		user.sendKeys("tomsmith");
		WebElement pass= webdriver.findElement(By.xpath("//input[@id=\"password\"]"));
		pass.sendKeys("SuperSecretPassword!");
		WebElement login= webdriver.findElement(By.xpath("//button"));
		login.click();
		WebElement logout= webdriver.findElement(By.xpath("//a[@href=\"/logout\"]"));
		logout.click();
		String urlValue= webdriver.getCurrentUrl();
		assertTrue(urlValue.contains("/login"));
	}
	
	
}
