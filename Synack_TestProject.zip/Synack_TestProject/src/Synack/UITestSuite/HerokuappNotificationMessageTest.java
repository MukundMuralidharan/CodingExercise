package Synack.UITestSuite;


import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertNotNull;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import org.testng.annotations.Test;

public class HerokuappNotificationMessageTest extends HerokuappNotificationSetup {
	
	
	
	@Test
	public void notificationMessageNotPresentOnLoadTest() {
		webdriver.navigate().to(" https://the-internet.herokuapp.com/notification_message_rendered");
		assertFalse(!(webdriver.findElement(By.xpath("//a[@href=\"/notification_message\"]")).isDisplayed()));
	}
	@Test
	public void notificationMessageTest() {
		webdriver.navigate().to(" https://the-internet.herokuapp.com/notification_message_rendered");
		WebElement clickable=webdriver.findElement(By.xpath("//a[@href=\"/notification_message\"]"));
		clickable.click();
		String flashMsg= webdriver.findElement(By.xpath("//div[@id=\"flash-messages\"]")).getText();
		System.out.println("text:"+flashMsg);
		assertNotNull(flashMsg);
	}
    
  
}
