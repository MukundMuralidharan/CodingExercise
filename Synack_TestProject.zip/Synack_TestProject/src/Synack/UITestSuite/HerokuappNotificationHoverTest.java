package Synack.UITestSuite;

import org.testng.annotations.Test;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
//import org.testng.annotations.BeforeTest;


public class HerokuappNotificationHoverTest extends HerokuappNotificationSetup{
  
 
  @Test
	public void herokuappHoverUser1Test() {
	  webdriver.navigate().to("https://the-internet.herokuapp.com/hovers");
	  Actions action = new Actions(webdriver);
	  WebElement hovers= webdriver.findElement(By.xpath("//div[1]/img"));
	  action.moveToElement(hovers).click().build().perform();
	  action.moveToElement(webdriver.findElement(By.xpath("//*[@id=\"content\"]/div/div[1]/div/a"))).click().perform();
	  String browserValue= webdriver.getCurrentUrl();
	  System.out.println(browserValue);
	  assertTrue(browserValue.contains("/users/1"));
	  webdriver.navigate().back();
	
	 
	}
  @Test
	public void herokuappHoverUser2Test() {
	  Actions action = new Actions(webdriver);
	  WebElement we = webdriver.findElement(By.xpath("//div[2]/img"));
	  action.moveToElement(we).build().perform();
	  action.moveToElement(webdriver.findElement(By.xpath("//*[@id=\"content\"]/div/div[2]/div/a"))).click().perform();
	  String browserValue= webdriver.getCurrentUrl();
	  assertTrue(browserValue.contains("/users/2"));
	  webdriver.navigate().back();
	  
	}
  @Test
	public void herokuappHoverUser3Test() {
	  Actions action = new Actions(webdriver);
	  WebElement we = webdriver.findElement(By.xpath("//div[3]/img"));
	  action.moveToElement(we).build().perform();
	  action.moveToElement(webdriver.findElement(By.xpath("//*[@id=\"content\"]/div/div[3]/div/a"))).click().perform();
	  String browserValue= webdriver.getCurrentUrl();
	  assertTrue(browserValue.contains("/users/3"));
	  webdriver.navigate().back();
	  
	}
  
}
