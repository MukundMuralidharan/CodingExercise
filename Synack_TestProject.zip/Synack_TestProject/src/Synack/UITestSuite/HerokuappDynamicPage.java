package Synack.UITestSuite;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class HerokuappDynamicPage extends HerokuappNotificationSetup {
  @Test
  public void herokuappDynamicPageContentTest() {
	  webdriver.navigate().to("https://the-internet.herokuapp.com/dynamic_content");
	  List<String> firstList= new ArrayList<String>();
	  List<String> secondList= new ArrayList<String>();
	  WebElement dynvalue1= webdriver.findElement(By.xpath("//div[@class=\"large-10 columns large-centered\"]/div[1]"));
	  firstList.add(dynvalue1.getText());
	  WebElement dynvalue2= webdriver.findElement(By.xpath("//div[@id]/div[2]"));
	  firstList.add(dynvalue2.getText());
	  WebElement dynvalue3= webdriver.findElement(By.xpath("//div[@id]/div[3]"));
	  firstList.add(dynvalue3.getText());
	  
	  webdriver.navigate().refresh();
	  
	  WebElement dynValue1= webdriver.findElement(By.xpath("//div[@class=\"large-10 columns large-centered\"]/div[1]"));
	  secondList.add(dynValue1.getText());
	  WebElement dynValue2= webdriver.findElement(By.xpath("//div[@id]/div[2]"));
	  secondList.add(dynValue2.getText());
	  WebElement dynValue3= webdriver.findElement(By.xpath("//div[@id]/div[3]"));
	  secondList.add(dynValue3.getText());
	  
	  Assert.assertNotEquals(firstList, secondList);
  }
}
